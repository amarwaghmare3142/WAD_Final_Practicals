console.log("Name:- Amar Waghmare")
console.log("Class:- TE (IT)")
console.log("Subject:- WAD")
console.log("Practicat No 2B")