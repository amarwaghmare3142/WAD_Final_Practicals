console.log("Name:Pradnya Ransing");
console.log("Class:TE");
console.log("Subject:WAD Practicals");
console.log("Assignment: 2-B");